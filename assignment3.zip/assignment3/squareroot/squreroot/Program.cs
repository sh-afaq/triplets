﻿namespace squreroot
{
    internal class Program
    {
        internal class binary
        {

            public static void sqrt(int x)
            {
                int left=0,right=x;
                int mid=0;
                mid=(left+right)/2;
                while(mid>0)
                {
                    if(mid*mid==x)
                    {
                        Console.WriteLine(mid);
                    }
                    mid--;
                }
                Console.WriteLine("not a perfect square root" + mid);
            }

                
        
        }
        static void Main(string[] args)
        {
            int number = 9;
            binary obj=new binary(); 
            obj.sqrt(number);
           // Console.WriteLine(result);
        }
    }
}