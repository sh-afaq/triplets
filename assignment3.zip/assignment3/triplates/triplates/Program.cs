﻿using System;

namespace triplates
{
    internal class Program
    {
        internal class triplates
        {
            public static void points(int[] arr, int[] s)
            {
                int a_count = 0, b_count = 0; 
                for(int i=0; i<arr.Length;i++)
                {
                    if (arr[i] > s[i])
                    {
                        a_count++;
                    }
                    else if (arr[i] < s[i])
                    {
                        b_count++;
                    }
                }
                int[] final =new int[] { a_count,b_count};
                /*for (int j=0;j<final.Length;j++)
                {
                    Console.WriteLine(final[j]);
                }*/
                Console.WriteLine("{0}", string.Join(", ", final));
            }
        }
        static void Main(string[] args)
        {
            int[] arr = {5,6,7 };
            int[] new_array = {3,6,10 };
            triplates obj=new triplates();

            obj.points(arr, new_array);
        }
    }
}