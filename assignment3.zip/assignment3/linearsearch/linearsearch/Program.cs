﻿namespace linearsearch
{
    internal class Program
    {
       internal class linear
        {
            public void search(int[] arr,int value)
            {
                for(int i=0;i<arr.Length;i++)
                {
                    if (arr[i]==value)
                    {
                        Console.WriteLine("value found at: " +i);
                        break;
                    }
                }
            }
        }


        static void Main(string[] args)
        {
            linear obj = new linear();
            int[] new_array = { 3, 8, 7, 5, 4 };
            obj.search(new_array, 7);
        }
    }
}