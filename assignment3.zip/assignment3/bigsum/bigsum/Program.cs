﻿namespace bigsum
{
    internal class Program
    {
        class result
        {
            public static long averybigsum(long[] arr)
            {
                long sum = 0;
                for (int i=0;i<arr.Length;i++)
                {
                     sum = sum + arr[i];
                }
                return sum;
            }
        }
        static void Main(string[] args)
        {
            
            long[] new_array = { 1000000001, 1000000002, 1000000003, 1000000004, 1000000005 };
            long answer=result.averybigsum(new_array);
            Console.WriteLine(answer);
        }
    }
}