﻿namespace arraysum
{
    internal class Program
    {
        static int find_sum(int[] arr)
            
        {
            int sum = 0;
            for (int i=0;i<arr.Length;i++)
            {
                sum = sum + arr[i];
            }
            return sum;
        }
        static void Main(string[] args)
        {
            int[] s = { 1, 6, 9, 4, 2 };
            int result=find_sum(s);
            Console.WriteLine("THE SUM IS : " +result);
        }
    }
}