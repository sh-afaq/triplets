﻿namespace general_ds
{
    internal class Program
    {
        internal class generic
        {
            int[] array = new int[5] ; int n = 5;
            int front = -1, rear = 0;int top = -1;
           
            public void enqueue()
            {
               
                while(rear<n-1)
                {
                    Console.WriteLine("enter value to add in queue");
                    int val = Int32.Parse(Console.ReadLine());
                    if (front==-1)
                    {
                        front=0;
                        array[front] = val;
                    }
                    else
                    {

                        rear++;
                        array[rear] = val;
                           

                    }
                }

            }
            public void dequeue()
            {
                if(front==-1)
                {
                    Console.WriteLine("queue is empty");
                }
                else
                {
                    Console.WriteLine("value deleted is :" + array[front]);
                    front++;
                    
                }
            }
            public void display_queue()
            {
                for(int i=front;i<=rear;i++)
                {
                    Console.WriteLine(array[i]);
                    
                }
            }
            public void push()
            {
                while (top <= n-2)
                {
                    Console.WriteLine("enter value to add in stack");
                    int value = Int32.Parse(Console.ReadLine());
                    top++;
                    array[top] = value;
                    


                }
            }
            public void pop()
            {
                top--;
                Console.WriteLine("value pop");
                
                
            }
            public void display_stack()
            {
                
                for(int i=top;i>=0;i--)
                {
                    Console.WriteLine(array[i]);
                    

                }
            }
        }
        static void Main(string[] args)
        {

            generic obj = new generic();
            Console.WriteLine("Enter number of operations you want to perform");
            int number = Int32.Parse(Console.ReadLine());
            while (number > 0)
            {
                Console.WriteLine(" if you want to use queue, enter Q ,if you want to use stack , enter S");
               string option = Console.ReadLine();
                if (option == "q" || option == "Q")
                {
                    Console.WriteLine(" if you want to add elemnet in queue enter 'e' ,if you want to remove element from queue enter 'd' , if you want to display queue" +
                        "enter 'dis' ");
                    string answer = Console.ReadLine();
                    if (answer == "e" || answer == "E")
                    {
                        obj.enqueue();
                        number--;
                    }
                    else if (answer == "d" || answer == "D")
                    {
                        obj.dequeue();
                        number--;
                    }
                    else if (answer == "dis" || answer == "Dis")
                    {
                        obj.display_queue();
                        number--;
                    }
                    else
                    {
                        Console.WriteLine(" please enter valid option");
                    }
                }
                else if (option == "S" || option == "s")
                {
                    Console.WriteLine(" if you want to add elemnet in stack enter 'push' ,if you want to remove element from stack enter 'pop' , if you want " +
                        "to display stack" +
                        "enter 'display' ");
                    string answer = Console.ReadLine();
                    if (answer == "push")
                    {
                        obj.push();
                        number--;
                    }
                    else if (answer == "pop")
                    {
                        obj.pop();
                        number--;
                    }
                    else if (answer == "display")
                    {
                        obj.display_stack();
                        number--;
                    }
                    else
                    {
                        Console.WriteLine(" please enter valid option");
                    }
                }
                else
                {
                    Console.WriteLine("please enter valid option");
                }
            }

           
        }
    }
}