﻿namespace binarysearch
{
    internal class Program
    {
        internal class algorithm
        {
            public void search(int[] arr, int value)
            {
                int start = 0, end = arr.Length - 1;
                int mid;

                while (end - start >= 1)
                {
                    mid = (start + end) / 2;
                    if (value > arr[mid])
                    {

                        end++;
                    }
                    else if (value < arr[mid])
                    {

                        //start++;
                        end = mid;
                    }
                    else if (value == arr[mid])
                    {
                        Console.WriteLine("value found at: " + mid);
                        break;
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            int[] s = { 1, 2, 3, 4, 5 };
            algorithm obj = new algorithm();
            obj.search(s, 2);
        }
    }
}